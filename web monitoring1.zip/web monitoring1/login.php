<?php
    session_start();
    error_reporting(0);
    $conn = mysqli_connect('localhost','inoprexc_bewok','dzailfc17','inoprexc_skripsi');
?>

<!DOCTYPE html>
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>login page</title>
    <!-- Favicon-->

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="assets/plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="assets/plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="assets/plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body class="login-page" style="background: green;">
    <div class="login-box">
        <div class="logo">
            <a href="javascript:void(0);"><b>CV</b> Pirius Jaya Abadi</a>
            <small>Silahkan Login Terlebih Dahulu!</small>
        </div>
        <div class="card">
            <div class="body">
                <form id="sign_in" method="post">
                    <div class="msg">Masukkan Username dan Password Anda!</div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">person</i>
                        </span>
                        <div class="form-line">
                            <input type="text" class="form-control" name="username" placeholder="Username" autocomplete="off" required autofocus>
                        </div>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="password" placeholder="Password" autocomplete="off" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-4">
                            <input type="submit" name="login" value="login" class="btn btn-block bg-teal waves-effect">
                        </div>
                    </div>
                </form>

                <?php
                    $username = $_POST['username'];
                    $password = $_POST['password'];

                    $login = $_POST['login'];
                    if($login){
                        $masuk = $conn->query("SELECT * FROM user WHERE username='$username' AND password='$password'");
                        $benar = $masuk->num_rows;
                        $data = $masuk->fetch_assoc();
                        if($benar >= 1){
                            session_start();
                            if($data['level'] == 'admin'){
                                $_SESSION['admin'] = $data[id_user];
                                header('location:index.php');
                            }
                        }else{
                            echo "<script>alert('Oops... Anda Gagal Login. Periksa Kembali Username dan Password Anda!')</script>";
                        }
                    }
                ?>

            </div>
        </div>
    </div>

    <!-- Jquery Core Js -->
    <script src="assets/plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="assets/plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="assets/plugins/node-waves/waves.js"></script>

    <!-- Validation Plugin Js -->
    <script src="assets/plugins/jquery-validation/jquery.validate.js"></script>

    <!-- Custom Js -->
    <script src="assets/js/admin.js"></script>
    <script src="assets/js/pages/examples/sign-in.js"></script>

</body>
</html>


