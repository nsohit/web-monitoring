<?php
    session_start();
    error_reporting(0);
        $conn = mysqli_connect('localhost','inoprexc_bewok','dzailfc17','inoprexc_skripsi');
    if(!isset($_SESSION['admin'])){
        header('location:login.php');
    }
?>

<!doctype html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <!-- Required meta tags -->
    
    <meta http-equiv="refresh" content="10">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="admin.css">
    <link rel="stylesheet" type="text/css" href="fontawesome-free/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/data.js"></script>
    <script src="https://code.highcharts.com/modules/series-label.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    

    <title>CV Pirius Jaya Abadi</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-success fixed-top">
      <a class="navbar-brand" href="#">Selamat Datang Admin | <b>CV Pirius Jaya Abadi</b></a>
    
        <form class="form-inline my-2 my-lg-0 ml-auto">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-primary btn-outline-primary my-2 my-sm-0" type="submit" style="color:white;">Search</button>
          <button class="btn btn-danger btn-outline-danger my-2 my-sm-0" type="submit"><a href="logout.php" style="color:white;">Logout</a></button>
        </form>

      </div>
    </nav>
     
    <div class="row no-gutters mt-5">
      <div class="col-md-2 bg-dark mt-2 pr-3 pt-4">
        <ul class="nav flex-column ml-3 mb-5">
          <li class="nav-item">
            <a class="nav-link active text-white" href="?views=dashboard"><i class="fas fa-tachometer-alt mr-2"></i> Dashboard</a><hr class=" bg-secondary">
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="?views=suhu"><i class="fas fa-thermometer-three-quarters mr-2"></i> Suhu</a><hr class=" bg-secondary">
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="?views=guncangan"><i class="fas fa-square-full mr-2"></i> Guncangan</a><hr class=" bg-secondary">
          </li>   
          <li class="nav-item">
            <a class="nav-link text-white" href="?views=maps"><i class="fas fa-map-marker-alt mr-2"></i> Maps</a><hr class=" bg-secondary">
          </li>
           <li class="nav-item">
            <a class="nav-link text-white" href="?views=status"><i class="fas fa-info mr-2"></i> Status</a><hr class=" bg-secondary">
          </li>

        </ul>
      </div>
      <div class="col-md-10 p-5 pt-2">
        <?php
            $views = $_GET['views'];
            $aksi = $_GET['aksi'];

            if($views == 'dashboard' || $views == ''){
                if($aksi == ''){
                    include 'views/dashboard.php';
                }
              }

            if($views == 'suhu' || $views == ''){
              if($aksi == ''){
                  include 'views/suhu.php';
              }
            }

            if($views == 'guncangan' || $views == ''){
              if($aksi == ''){
                include 'views/guncangan.php';
              }
            }

            if($views == 'maps' || $views == ''){
              if($aksi == ''){
                include 'views/maps.php';
              }
            } 

            if($views == 'status' || $views == ''){
              if($aksi == ''){
                  include 'views/status.php';
              }
            }

        ?>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="admin.js"></script>
  </body>
</html>