<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Halaman | Status</title>
</head>
<body>
<div class="col-md-10 p-5 pt-2">
         <h3> <i class="fas fa-info mr-2"></i>Status</h3><hr>
         <table class="table table-striped table-border">
          <thead>
            <tr>
              <th scope="col">NO</th>
               <th scope="col">ID USER</th>
              <th scope="col">STATUS</th>
              <th scope="col">WAKTU</th>
            </tr>
          </thead>
          <tbody>
          <?php
            $no = 1;
            $read = $conn->query("SELECT iduser, status, waktu FROM data ORDER BY no ASC limit 10");
            while($data = $read->fetch_assoc()){
          ?>
            <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $data["iduser"]; ?></td>
              <td><?php echo $data["status"]; ?></td>
              <td><?php echo $data["waktu"]; ?></td>
            </tr>
            <?php $no++; ?>
            <?php } ?>
          </tbody>
        </table>
      </div>
</body>
</html>