<?php
  if (isset($_POST["submit_address"])){
    $address = $_POST["address"];
    $address = str_replace(" ","+","$address");
    ?>
      <iframe src="https://maps.google.com/maps?q=<?php echo $address; ?>&output=embed" width="100%" height="500"></iframe>
    <?php
  }
  if (isset($_POST["submit_coordinates"])){
    $latitude = $_POST["latitude"];
    $longitude = $_POST["longitude"];
    $latitude = str_replace(" ","+","$latitude");
    $longitude = str_replace(" ","+","$longitude");
    ?>
      <iframe src="https://maps.google.com/maps?q=<?php echo $latitude; ?>,<?php echo $longitude; ?>&output=embed" width="100%" height="500"></iframe>
    <?php
  }
?>

<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Halaman | Maps</title>
</head>
<body>
<h3> <i class="fas fa-map-marker-alt mr-2"></i>Maps</h3><hr>

<form method="post">
      <p>Alamat</p>
      <p><input type="text" name="address" placeholder="Masukkan Alamat"></p>
      <input type="submit" name="submit_address">
</form>
<br><br>
<form method="post">
<?php
  $read = $conn->query("SELECT * FROM data WHERE latitude AND longitude ORDER BY no DESC LIMIT 1");
  while($data = $read->fetch_assoc()){
?>
<p>Latitude</p>
<p><input type="text" name="latitude" value="<?php echo $data["latitude"]; ?>"></p>
<p>Longitude</p>
<p><input type="text" name="longitude" value="<?php echo $data["longitude"]; ?>"></p>
<input type="submit" name="submit_coordinates">
  <?php } ?>
</form>


<div class="col-md-10 p-5 pt-2">
         <table class="table table-striped table-border">
          <thead>
            <tr>
              <th scope="col">NO</th>
              <th scope="col">LATITUDE</th>
               <th scope="col">LONGITUDE</th>
              <th scope="col">WAKTU</th>
            </tr>
          </thead>
          <tbody>
              <?php 
                $no = 1;
                $read = $conn->query("SELECT latitude,longitude,waktu FROM data ORDER BY no DESC LIMIT 10");
                while($data = $read->fetch_assoc()){
              ?>
            <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $data["latitude"]; ?></td>
              <td><?php echo $data["longitude"]; ?></td>
              <td><?php echo $data["waktu"]; ?></td>
            </tr>
            <?php $no++; ?>
                <?php } ?>
          </tbody>
        </table>
      </div>

     <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB_ZQT6z-YvD7qjxm2mL6x87w5CmB8u2mQ&callback=initMap" async defer ></script>
  
</body>
</html>