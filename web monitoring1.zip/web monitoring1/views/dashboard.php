<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Halaman | Dashboard</title>
</head>
<body>
   
  <div class="row mt-5">
    <div class="col-md-12 p-5 pt-2" style="margin-top: -100px;">
       <h3> <i class="fas fa-tachometer-alt mr-2 "></i> Dashboard</h3><hr>

       <div class="row text-white">
         <div class="card bg-info ml-5" style="width: 430px;">
          <div class="card-body">
            <div class="card-body-icon">
              <i class="fas fa-thermometer-three-quarters mr-2"></i>
            </div>
            <?php 
                $read = $conn->query("SELECT dhtA FROM data ORDER BY no DESC LIMIT 1");
                while($data = $read->fetch_assoc()):
            ?>
            <h5 class="card-title">Suhu</h5>
            <div class="display-4"><?php echo $data["dhtA"]; ?></div>
            <a href="?views=suhu"><p class="card-text text-white">lihat detail <i class="fasfa-angle-double-right ml-2"></i></p></a>
            <?php endwhile ?>
          </div>
        </div>
        
         <div class="card bg-success ml-5" style="width: 430px;">
          <div class="card-body">
            <div class="card-body-icon">
              <i class="fas fa-info mr-2"></i></i>
            </div>
            <?php 
                $read = $conn->query("SELECT status FROM data ORDER BY no DESC LIMIT 1");
                while($data = $read->fetch_assoc()):
            ?>
            <h5 class="card-title">Status</h5>
            <div class="display-4"><?php echo $data["status"]; ?></div>
              <a href="?views=status"><p class="card-text text-white">lihat detail <i class="fasfa-angle-double-right ml-2"></i></p></a>
            <?php endwhile ?>
          </div>
        </div>
    </div>

    <hr>
    
    </div>
  </div>

    <div class="row">
    <div class="col-md-12">
      <div id="chart">

      </div>
    </div>
  </div>
  
  

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script type="text/javascript">
Highcharts.chart('chart', {
    chart: {
        type: 'area'
    },
    title: {
        text: 'Hightchart'
    },
    subtitle: {
        text: 'Source: CV Pirius Jaya Abadi'
    },
    xAxis: {
        tickmarkPlacement: 'on',
        title: {
            enabled: false
        }
    },
    yAxis: {
        title: {
            text: '2020'
        },
        labels: {
            formatter: function () {
                return this.value;
            }
        }
    },
    tooltip: {
        split: true,
        valueSuffix: ' millions'
    },
    plotOptions: {
        area: {
            stacking: 'normal',
            lineColor: '#666666',
            lineWidth: 1,
            marker: {
                lineWidth: 1,
                lineColor: '#666666'
            }
        }
    },
    series: [{
        name: 'TANGERANG',
        data: [
          <?php
            $read = $conn->query("SELECT adxlA FROM data ORDER BY no ASC");
            while($data = $read->fetch_assoc()){
          ?>
          [<?php echo $data['adxlA']; ?>],
          <?php } ?>
        ]
    }]
});
</script>
   

</body>
</html>