<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Halaman | Guncangan</title>
</head>
<body>

<div class="row">
    <div class="col-md-12">
      <div id="chart">

      </div>
    </div>
  </div>

<div class="col-md-10 p-5 pt-2">
         <h3> <i class="fas fa-square-full mr-2"></i>Guncangan</h3><hr>
         <table class="table table-striped table-border">
          <thead>
            <tr>
              <th scope="col">NO</th>
              <th scope="col">GUNCANGAN</th>
              <th scope="col">WAKTU</th>
            </tr>
          </thead>
          <tbody>
          <?php
            $no = 1;
            $read = $conn->query("SELECT adxlA, waktu FROM data ORDER BY no DESC LIMIT 10");
            while($data = $read->fetch_assoc()){
          ?>
            <tr>
              <td><?php echo $no; ?></td>
              <td><?php echo $data["adxlA"]; ?></td>
              <td><?php echo $data["waktu"]; ?></td>
            </tr>
          <?php $no++; ?>
          <?php } ?>
          </tbody>
        </table>
      </div>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script type="text/javascript">
Highcharts.chart('chart', {
    chart: {
        type: 'area'
    },
    title: {
        text: 'Hightchart'
    },
    subtitle: {
        text: 'Source: PT Pirius Jaya Abadi'
    },
    xAxis: {
        tickmarkPlacement: 'on',
        title: {
            enabled: false
        }
    },
    yAxis: {
        title: {
            text: '2020'
        },
        labels: {
            formatter: function () {
                return this.value;
            }
        }
    },
    tooltip: {
        split: true,
        valueSuffix: ' millions'
    },
    plotOptions: {
        area: {
            stacking: 'normal',
            lineColor: '#666666',
            lineWidth: 1,
            marker: {
                lineWidth: 1,
                lineColor: '#666666'
            }
        }
    },
    series: [{
        name: 'TANGERANG',
        data: [
          <?php
            $read = $conn->query("SELECT adxlA FROM data ORDER BY no ASC LIMIT 10");
            while($data = $read->fetch_assoc()){
          ?>
          [<?php echo $data['adxlA']; ?>],
          <?php } ?>
        ]
    }]
});
</script>
</body>
</html>