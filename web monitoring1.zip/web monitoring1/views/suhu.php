<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Halaman | Suhu</title>
</head>
<body>
  
  <div class="col-md-10 p-5 pt-2">
      <h3><i class="fas fa-thermometer-three-quarters mr-2"></i>Suhu</h3><hr>
      <table class="table table-striped table-border">
      <thead>
        <tr>
          <th scope="col">NO</th>
          <th scope="col">SUHU</th>
          <th scope="col">WAKTU</th>
        </tr>
      </thead>
      <tbody>
      <?php
          $no = 1;
          $read = $conn->query("SELECT * FROM data WHERE dhtA AND waktu LIMIT 10");
          while($data = $read->fetch_assoc()){
      ?>
        <tr>
          <td><?php echo $no; ?></td>
          <td><?php echo $data["dhtA"]; ?></td>
          <td><?php echo $data["waktu"]; ?></td>
        </tr>
      <?php $no++; ?>
      <?php } ?>
      </tbody>
    </table>
  </div>

</body>
</html>