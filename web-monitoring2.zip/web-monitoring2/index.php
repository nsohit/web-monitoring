<?php
        $conn = mysqli_connect('localhost','root','','monoksida');
    
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>

  <!-- Chart--->
 
   <!--akhirchart-->

  <!--myfont-->
<link href="https://fonts.googleapis.com/css2?family=Rowdies:wght@300&display=swap" rel="stylesheet">

  <!--mycss-->
  <link rel="stylesheet" type="text/css" href="style.css">

  <body>


   <!--navbar-->
  <nav class="navbar navbar-expand-lg navbar-light ">
    <div class="container">
    <a class="navbar-brand" href="#">hallo</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
        <a class="nav-item nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
        <a class="nav-item nav-link" href="admin.php">Admin</a>
        
      </div>
    </div>
    </div>
  </nav>
  <!-- Akhir navbar-->

  <!--jumbotron-->
    <div class="jumbotron ">
    <div class="container">
      <h1 class="display-4"><span>Monitoring System<br>Now</br></span></h1>
   <button type="button" class="btn btn-outline-warning">Learn more</button>
    </div>
  </div>
  <!--Akhir jumbotron-->


  <!--awal jumbotron-->
<div class="container-fluid">
  <div class="row justify-content-md-left">
    <div class="row">
<div class="card shadow mb-6" style="">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Monitoring suhu</h6>
                </div>
                <div class="card-body text-center">
                  <div class="chart-area">
                   <div id="columnchart_material" style="width: 800px; height: 500px; size: cover"></div>
                  </div>
                </div>
              </div>
 <div class="card shadow mb-6" style="">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Nilai Rata-</h6>
                </div>

                <?php
                $query3=mysqli_query($conn, "SELECT SUM(karbon) AS total_row FROM data");
                $data3=mysqli_fetch_array($query3);
                $query4=mysqli_query($conn, "SELECT count(karbon) AS total_nilai FROM data");
                $data4=mysqli_fetch_array($query4);
                $row=$data3['total_row'];
                $jumlah=$data4['total_nilai'];
                $rata2=$jumlah/$row;
                ?>
                <div class="card-body text-center">
                  <div class="chart-area">
                   <div id="columnchart_material2" style="width: 400px; height: 200px; size: cover">
                      <div class="display-4"><?php echo "$rata2"; ?></div>
                   </div>
                  </div>


<!--end jumbotron-->

<?php
$sql = "INSERT INTO data2 (avarage) VALUES ('" . $rata2 . "')";
 if (mysqli_query($conn, $sql)) {

} else {
      
}
?>
<!---chart-->
  <script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script type="text/javascript">
Highcharts.chart('columnchart_material', {
    chart: {
        type: 'area'
    },
    title: {
        text: 'chart'
    },
    subtitle: {
        text: 'pim1'
    },
    xAxis: {
        tickmarkPlacement: 'on',
        title: {
            enabled: false
        }
    },
    yAxis: {
        title: {
            text: '2020'
        },
        labels: {
            formatter: function () {
                return this.value;
            }
        }
    },
    tooltip: {
        split: true,
        valueSuffix: ' derajat'
    },
    plotOptions: {
        area: {
            stacking: 'normal',
            lineColor: '#666666',
            lineWidth: 1,
            marker: {
                lineWidth: 1,
                lineColor: '#666666'
            }
        }
    },
     series: [{
        name: 'Jakarta',
        data: [
          <?php
            $read = $conn->query("SELECT karbon FROM data ORDER BY no ASC LIMIT 10");
            while($data = $read->fetch_assoc()){
          ?>
          [<?php echo $data['karbon']; ?>],
          <?php } ?>
        ]
    }]
});
</script>
<!--akhirchart-->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>