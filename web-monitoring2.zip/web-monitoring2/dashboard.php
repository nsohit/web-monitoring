<?php  
 $connect = mysqli_connect("localhost", "root", "", "monoksida");  
 $query = "SELECT * FROM data ORDER BY no desc";  
 $result = mysqli_query($connect, $query);


  function fetch_data()  
 {   

 
  if(isset($_POST["tgl_a"], $_POST["tgl_b"])){ 
      $output = '';  
      $conn = mysqli_connect("localhost", "root", "", "monoksida");  
      $sql = "  
          SELECT * FROM data 
           WHERE tanggal BETWEEN '".$_POST["tgl_a"]."' AND '".$_POST["tgl_b"]."' 
      "; 
      $result = mysqli_query($conn, $sql);  
      while($row = mysqli_fetch_array($result))  
      {       
      $output .= '<tr>  
                          <td>'.$row["no"].'</td>  
                          <td>'.$row["karbon"].'</td>  
                          <td>'.$row["waktu"].'</td>  
                          <td>'.$row["tanggal"].'</td>  
                     </tr>  
                          ';  
      }  
      return $output;  
 }
 }  
 if(isset($_POST["generate_pdf"]))  
 {  
      require_once('/opt/lampp/phpmyadmin/vendor/tecnickcom/tcpdf/tcpdf.php');  
      $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
      $obj_pdf->SetCreator(PDF_CREATOR);  
      $obj_pdf->SetTitle("Generate HTML Table Data To PDF From MySQL Database Using TCPDF In PHP");  
      $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
      $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
      $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
      $obj_pdf->SetDefaultMonospacedFont('helvetica');  
      $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
      $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);  
      $obj_pdf->setPrintHeader(false);  
      $obj_pdf->setPrintFooter(false);  
      $obj_pdf->SetAutoPageBreak(TRUE, 10);  
      $obj_pdf->SetFont('helvetica', '', 11);  
      $obj_pdf->AddPage();  
      $content = '';  
      $content .= '  
      <h4 align="center">Generate HTML Table Data To PDF From MySQL Database Using TCPDF In PHP</h4><br /> 
      <table border="1" cellspacing="0" cellpadding="3">  
           <tr>  
                <th width="5%">No</th>  
                <th width="30%">Monoksida</th>  
                <th width="15%">Time</th>  
                <th width="50%">Date</th>  
           </tr>  
      ';  
      $content .= fetch_data();  
      $content .= '</table>';  
      $obj_pdf->writeHTML($content);  
      $obj_pdf->Output('file.pdf', 'I');  
 }
 ?>  
  
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <!-- calender -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
    <title>Hello, world!</title>
  </head>

  <!-- Chart--->
 
   <!--akhirchart-->

  <!--myfont-->


  <!--mycss-->
  <link rel="stylesheet" type="text/css" href="style2.css">

  <body>

<div class="wrapper">
    <div class="sidebar">
        <h2>Sidebar</h2>
        <ul>
            <li><a href="index.php"><i class="fas fa-home"></i>Home</a></li>
            <li><a href="admin.php"><i class="fa-sign-out"></i>Logout</a></li>
            
            
           
        </ul>
    </div>
    <div class="main_content">
        <div class="info">
          
      </div>
      <div class="container-fluid">
  <div class="row justify-content-md-right">

    <!-- Tabel-->
    <div class="row">
<div class="card shadow mb-6" style="">
                <div class="card-header py-3">   
                    <div class="col-md-12" align="right">
                     <form method="post"> 
                          <input type="submit" name="generate_pdf" class="btn btn-success" value="Generate PDF" /> 
                          <input type="date" class="from-control"   name="tgl_a" required />   
                          <input type="date" class="from-control"   name="tgl_b" required /> 
                     </form> 
                </div> 
                 
                </div>
                <div class="card-body text-center">
                  <div class="Tabel">
                   <table style="width: 1100px; height: 500px;  size: cover;">
                    <!-- tabel -->
                                              <tr>  
                               <th width="5%">No</th>  
                               <th width="30%">Monoksida</th>  
                               <th width="43%">Time</th>  
                               <th width="10%">Date</th>    
                          </tr>  
                     <?php  
                     while($row = mysqli_fetch_array($result))  
                     {  
                     ?>  
                          <tr>  
                               <td><?php echo $row["no"]; ?></td>  
                               <td><?php echo $row["karbon"]; ?></td>  
                               <td><?php echo $row["waktu"]; ?></td>  
                               <td><?php echo $row["tanggal"]; ?></td>  
                          </tr>  
                     <?php  
                     }  
                     ?>  
                     </table>  
                  </div>
                </div>
              </div>

  
    </div>
    
</div>
 </body>
</html>