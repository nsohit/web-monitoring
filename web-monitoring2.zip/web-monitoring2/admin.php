<?php
    session_start();
    error_reporting(0);
    $conn = mysqli_connect('localhost','root','','monoksida');
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>

  <!-- Chart--->
 
   <!--akhirchart-->

  <!--myfont-->
<link href="https://fonts.googleapis.com/css2?family=Rowdies:wght@300&display=swap" rel="stylesheet">

  <!--mycss-->
  <link rel="stylesheet" type="text/css" href="style.css">

  <body>


   <!--navbar-->
	<nav class="navbar navbar-expand-lg navbar-light ">
	  <div class="container">
	  <a class="navbar-brand" href="#">David</a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	    <div class="navbar-nav ml-auto">
	      <a class="nav-item nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
	      <a class="nav-item nav-link" href="admin.php">Loug Out</a>
	    </div>
	  </div>
	  </div>
	</nav>
  <!-- Akhir navbar-->

  <!--jumbotron-->
	  <div class="jumbotron admin-fix ">
	  	<div class="card ">
	  		<div id="card-title">
        <h2>LOGIN</h2>
        <div class="underline-title" style="align-items: center;"></div>
      </div>
      <form method="post" class="form">
        <label for="user" style="padding-top:13px">
            &nbsp;Username
          </label>
        <input id="user" class="form-content" type="text" name="username" autocomplete="on" required />
        <div class="form-border"></div>
        <label for="user-password" style="padding-top:22px">&nbsp;Password
          </label>
        <input id="user-password" class="form-content" type="password" name="password" required />
        <div class="form-border"></div>
        <a href="#">
          <legend id="forgot-pass">Forgot password?</legend>
        </a>
        <input id="submit-btn" type="submit" name="submit" value="LOGIN"/> <a ></a>
      </form>
      <?php
        $username = $_POST['username'];
        $password = $_POST['password'];
        $login = $_POST['submit'];
            if($login){
                        $masuk = $conn->query("SELECT * FROM user WHERE username='$username' AND password='$password'");
                        $benar = $masuk->num_rows;
                        $data = $masuk->fetch_assoc();
                        if($benar >= 1){
                            session_start();
                            if($data['level'] == 'admin'){
                                $_SESSION['admin'] = $data[id_user];
                                header('location:dashboard.php');
                            }
                        }else{
                            echo "<script>alert('Oops... Anda Gagal Login. Periksa Kembali Username dan Password Anda!')</script>";
                        }
                    }
      ?>
    </div>
  </div>





</body>
</html>